from django import forms
from .models import Assignment, Submission, Feedback



class SubmissionForm(forms.ModelForm):
    assignment_id = forms.IntegerField(widget=forms.HiddenInput())  # Hidden field for assignment_id

    class Meta:
        model = Submission
        fields = ['file', 'assignment_id']  # Exclude 'student' from the form

class AssignmentForm(forms.ModelForm):
    class Meta:
        model = Assignment
        fields = ['title', 'description', 'deadline']


class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ['comments', 'grade']