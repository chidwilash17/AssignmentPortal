from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Assignment, Submission, Feedback
from .forms import AssignmentForm, SubmissionForm, FeedbackForm

# Student view: Submit assignment
def submit_assignment(request):
    if request.method == 'POST':
        form = SubmissionForm(request.POST, request.FILES)
        if form.is_valid():
            assignment_id = form.cleaned_data['assignment_id']  # Retrieve assignment_id from the form
            assignment = get_object_or_404(Assignment, id=assignment_id)
            submission = form.save(commit=False)
            submission.assignment = assignment
            if request.user.is_authenticated:  # Check if the user is logged in
                submission.student = request.user  # Assign the logged-in user
            else:
                submission.student = None  # Set student to NULL for anonymous users
            submission.save()
            return redirect('assignment_list')
    else:
        assignment_id = request.GET.get('assignment_id')  # Get assignment_id from the query string
        assignment = get_object_or_404(Assignment, id=assignment_id)
        form = SubmissionForm(initial={'assignment_id': assignment_id})  # Pre-fill the hidden field
    return render(request, 'submit_assignment.html', {'form': form, 'assignment': assignment})

# Teacher view: Select assignment to view submissions
def select_assignment(request):
    if request.method == 'POST':
        assignment_id = request.POST.get('assignment')  # Get assignment_id from the form
        request.session['assignment_id'] = assignment_id  # Store assignment_id in session
        return redirect('view_submissions_without_id')
    else:
        assignments = Assignment.objects.all()
        return render(request, 'select_assignment.html', {'assignments': assignments})

# Teacher view: View submissions for a selected assignment (without assignment_id in URL)
def view_submissions_without_id(request):
    assignment_id = request.session.get('assignment_id')  # Retrieve assignment_id from session
    if not assignment_id:
        return redirect('select_assignment')  # Redirect if no assignment is selected

    assignment = get_object_or_404(Assignment, id=assignment_id)
    submissions = Submission.objects.filter(assignment=assignment)
    return render(request, 'view_submissions.html', {'submissions': submissions, 'assignment': assignment})

# Teacher view: View submissions for a specific assignment (with assignment_id in URL)
def view_submissions(request, assignment_id):
    assignment = get_object_or_404(Assignment, id=assignment_id)
    submissions = Submission.objects.filter(assignment=assignment)
    return render(request, 'view_submissions.html', {'submissions': submissions, 'assignment': assignment})

# Teacher view: Leave feedback for a submission
def leave_feedback(request, submission_id):
    submission = get_object_or_404(Submission, id=submission_id)
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback = form.save(commit=False)
            feedback.submission = submission
            feedback.teacher = request.user
            feedback.save()
            return redirect('view_submissions', assignment_id=submission.assignment.id)  # Redirect to view_submissions with assignment_id
    else:
        form = FeedbackForm()
    return render(request, 'leave_feedback.html', {'form': form, 'submission': submission})

# Admin view: Create assignments
@login_required
def create_assignment(request):
    if request.method == 'POST':
        form = AssignmentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('assignment_list')
    else:
        form = AssignmentForm()
    return render(request, 'create_assignment.html', {'form': form})

# List all assignments
def assignment_list(request):
    assignments = Assignment.objects.all()
    return render(request, 'assignment_list.html', {'assignments': assignments})